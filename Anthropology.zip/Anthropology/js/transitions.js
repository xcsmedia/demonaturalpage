window.sr = ScrollReveal();

	sr.reveal('.text-1', {
		duration: 3000,
		origin: 'bottom',
		distance: '200px',
	});
	sr.reveal('.img-1', {
		duration: 3000,
		origin: 'top',
		distance: '200px',
	});
		sr.reveal('.planta-img', {
		duration: 4000,
		origin: 'left',
		distance: '400px',
	});



var x = window.matchMedia("(max-width: 864px)")

window.sr = ScrollReveal();

	sr.reveal('.text-1', {
		duration: 3000,
		origin: 'top',
		distance: '100px',
	});
	sr.reveal('.img-1', {
		duration: 3000,
		origin: 'bottom',
		distance: '100px',
	});